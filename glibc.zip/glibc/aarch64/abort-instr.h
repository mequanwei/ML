#define ABORT_INSTRUCTION asm ("brk\t#1000")
